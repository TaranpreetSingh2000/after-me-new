import Navbar from "./Components/navbar/Navbar";
import MainComponents from "./Components/maincomponents/MainComponents";
import Footer from "./Components/footer/Footer";
import Signup from "./Components/Signup/Signup";
import Loginfile from "./Components/Login/Loginfile";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Otplogin from "./Components/Otplogin";
import Home from "./Components/home/Home";

const App = () => {
  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Loginfile />} />
          <Route path="/otplogin" element={<Otplogin />} />
          <Route
            path="/navbar"
            element={<Navbar logo="AYASYA" logoUrl="http://dev.ayasya.de/wp-content/uploads/2024/01/cropped-ayasya-logo-1.png" />}/>
          <Route path="/maincomp" element={<MainComponents />} />
          <Route path="/footer" element={<Footer />} />

        </Routes>
      </Router>
    </>
  );
};

export default App;
