import React from "react";
import Card from "../cards/Card";
import Style from "./MainComponents.module.css";
import Title from "../title/Title";
import Navbar from "../navbar/Navbar";
import Footer from "../footer/Footer";

const MainComponents = () => {
  const cardData = [
    {
      icon: "http://dev.ayasya.de/wp-content/uploads/2021/11/Home-10-icon-img3.png",
      title: "Personal Information",
    },
    {
      icon: "http://dev.ayasya.de/wp-content/uploads/2021/11/Home-10-icon-img3.png",
      title: "Medical History",
    },
    {
      icon: "http://dev.ayasya.de/wp-content/uploads/2021/11/Home-10-icon-img3.png",
      title: "Personal Close to My Heart",
    },
    {
      icon: "http://dev.ayasya.de/wp-content/uploads/2021/11/Home-10-icon-img3.png",
      title: "Ready Reference",
    },
    {
      icon: "http://dev.ayasya.de/wp-content/uploads/2021/11/Home-10-icon-img3.png",
      title: "Document Details",
    },
    {
      icon: "http://dev.ayasya.de/wp-content/uploads/2021/11/Home-10-icon-img3.png",
      title: "Insurence - LIC Policy Details",
    },
    {
      icon: "http://dev.ayasya.de/wp-content/uploads/2021/11/Home-10-icon-img3.png",
      title: "Medi Claim Policy Details",
    },
    {
      icon: "http://dev.ayasya.de/wp-content/uploads/2021/11/Home-10-icon-img3.png",
      title: "Vehicle Insurance Policy Details",
    },
  ];

  return (
    <div className={`container ${Style.main_component}`}>
    <Navbar/>
      <div className={Style.main_title}>
        <Title title="What my family should know" />
      </div>
      <div className="row">
        {cardData.map((card, index) => {
          return (
            <div className="col-lg-3 col-6 mt-4">
              <Card key={index} CardTitle={card.title} CardIcon={card.icon} />
            </div>
          );
        })}
      </div>
      <Footer/>
    </div>
  );
};

export default MainComponents;
