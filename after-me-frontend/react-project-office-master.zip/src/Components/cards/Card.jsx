import React from "react";
import style from "./card.module.css";

const Card = ({ key, CardTitle, CardIcon }) => {
  return (
    <div className={style.card} id={key}>
      <div className={style.inner_card}>
        <img className={style.image} src={CardIcon} alt={CardTitle} />
        <div className={style.card_title}>
          <h6>{CardTitle}</h6>
        </div>
      </div>
    </div>
  );
};

export default Card;
