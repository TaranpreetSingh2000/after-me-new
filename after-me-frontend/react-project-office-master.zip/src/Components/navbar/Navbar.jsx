import React from "react";
import Social from "../social/Social";
import style from "./Navbar.module.css";
import { useLocation } from 'react-router-dom';

const Navbar = (props) => {
  const location = useLocation();
  const { picture, givenName, otpnumber } = location.state || {};
  return (
    <div className={`container ${style.navbar}`}>
    {props.logoUrl ? (
        <img className={style.image} src={props.logoUrl} alt={props.logo} />
      ) : (
        <h2>{props.logo}</h2>
      )}

      <div className={`profile-section ${style.profileSection}`}>
        <Social />
        <a className="navbar-brand ms-2" href="#" > Welcome, {otpnumber ? otpnumber : givenName}
        </a>

        {picture && <img src={picture} alt='User Profile' className={style.profileicon} />}
      </div>
    </div>
  );
};

export default Navbar;
